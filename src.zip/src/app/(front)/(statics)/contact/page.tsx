export default async function TempPage() {
  return <div></div>;
}
