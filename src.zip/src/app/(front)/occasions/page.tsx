// src/app/occasions/page.tsx
import type { Metadata } from "next";
import OccasionsClient from "./OccasionsClient";

export const metadata: Metadata = {
  title: "تقویم مناسبت‌ها",
  description: "نمایش مناسبت‌های رسمی و شخصی پیش‌رو در تقویم.",
  alternates: { canonical: "/occasions" },
};

type WPOccasion = { acf?: { title?: string; occasion_date?: string } };

export default async function OccasionsPage() {
  const WP_BASE = process.env.WP_BASE_URL || "https://app.kadochi.com";
  let map: Record<string, string[]> = {};

  try {
    const res = await fetch(
      `${WP_BASE}/wp-json/wp/v2/occasion?acf_format=standard&per_page=100`,
      { next: { revalidate: 1800 } }
    );
    if (res.ok) {
      const json = (await res.json()) as unknown as WPOccasion[];
      const m: Record<string, string[]> = {};
      json.forEach((it) => {
        const d = it.acf?.occasion_date?.trim();
        const t = it.acf?.title?.trim();
        if (!d || !t) return;
        (m[d] ||= []).push(t);
      });
      map = m;
    }
  } catch {
    map = {};
  }

  return <OccasionsClient initialMap={map} />;
}
