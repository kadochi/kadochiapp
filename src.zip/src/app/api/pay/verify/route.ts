import { NextRequest, NextResponse } from "next/server";

import {
  UpstreamBadResponse,
  UpstreamNetworkError,
  UpstreamTimeout,
} from "@/services/http/errors";
import { verifyPayment } from "@/services/payment/zarinpal";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type VerifyBody = {
  Authority?: string;
  amount?: number;
  currency?: "IRT" | "IRR";
};

function noStore<T>(response: NextResponse<T>) {
  response.headers.set("Cache-Control", "no-store");
  return response;
}

function mapError(error: unknown) {
  if (error instanceof UpstreamTimeout) {
    return noStore(
      NextResponse.json(
        { ok: false, error: "upstream_timeout" },
        { status: error.status }
      )
    );
  }
  if (error instanceof UpstreamNetworkError) {
    return noStore(
      NextResponse.json(
        { ok: false, error: "upstream_network" },
        { status: error.status }
      )
    );
  }
  if (error instanceof UpstreamBadResponse) {
    if (error.status === 400 && error.message === "invalid_input") {
      return noStore(
        NextResponse.json({ ok: false, error: "invalid_input" }, { status: 400 })
      );
    }
    if (error.status === 500 && error.message === "missing_merchant_id") {
      return noStore(
        NextResponse.json(
          { ok: false, error: "missing_merchant_id" },
          { status: 500 }
        )
      );
    }
    const status = error.status >= 400 ? error.status : 502;
    return noStore(
      NextResponse.json(
        { ok: false, error: "zarinpal_verify_failed", status },
        { status }
      )
    );
  }
  const detail = error instanceof Error ? error.message : String(error);
  return noStore(
    NextResponse.json(
      { ok: false, error: "server_error", detail },
      { status: 500 }
    )
  );
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as VerifyBody;
    const authority = String(body?.Authority || "").trim();

    const result = await verifyPayment(
      {
        authority,
        amount: body.amount || 0,
        currency: body.currency,
      },
      { timeoutMs: 8_000 }
    );

    return noStore(
      NextResponse.json({
        ok: true,
        paid: result.paid,
        code: result.code,
        ref_id: result.ref_id,
        card_pan: result.card_pan,
        raw: result.raw,
      })
    );
  } catch (error) {
    return mapError(error);
  }
}