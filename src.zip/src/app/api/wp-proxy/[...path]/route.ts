export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export {
  OPTIONS,
  HEAD,
  GET,
  POST,
  PUT,
  PATCH,
  DELETE,
} from "../../wp/[...path]/route";
