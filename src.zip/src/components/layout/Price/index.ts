export { default as NormalPrice } from "./Normal/NormalPrice";
export { default as DiscountPrice } from "./Discount/DiscountPrice";
export { default as SumPrice } from "./Sum/SumPrice";
export { default as Price } from "./Price";
